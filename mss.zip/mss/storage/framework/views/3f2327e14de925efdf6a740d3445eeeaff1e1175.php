    <?php $__env->startSection('content'); ?> 
<div class="right_col" role="main">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="viewadminhead">
        <h2>Account Payable</h2>
      </div>
    </div>
  </div>
  <div class="row">
    <!-- <form method="post" action = "" class="login-form" enctype="multipart/form-data">
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div class="dateinputcircles">
          <div class="form-group">
            <input type="date" name="date_from">
          </div>
        </div>
      </div>
      <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
        <div class="Tohead">
          <h4>To</h4>
        </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div class="dateinputcircles">
          <div class="form-group">
            <input type="date" name="date_to">
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div class="Applybtn">
          <button href="#" class="btnapply btn">Apply</button>
        </div>
      </div>
    </form> -->
  </div>
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="Adminprofilebox">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="accountpayablehead">
                
              <h4>Company Name</h4>
              <h4>Account Payable Report</h4>
              <p>January 1-Faburary 10</p>
            </div>
          </div>
        </div>
        <table id="example" class="table" cellspacing="0" width="100%">
            
           
          <thead class="headbgcolor2">
            <tr>
              <th></th>
             
              <th>1-30</th>
              <th>31-60</th>
              <th>61-90</th>
              <th>91 and over</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
          <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
<?php

$supplier_name=$results->supplier_name;
$result = DB::select("select* from supplier where pk_id = '$supplier_name'");
?> 
          <tr>
            <td><strong><?php echo e($result[0]->supplier_name); ?></strong></td>
            <!-- 1--30 -->
            <?php if( $results->total_amount <= '30000' ): ?>
            <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
            <?php else: ?>
            <td>00</td>
            <?php endif; ?>
            <!-- 31---60 -->
            <?php if($results->total_amount >='30000' && $results->total_amount <= "60000" ): ?>
            <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
            <?php else: ?>
            <td>00</td>
            <?php endif; ?>


            <?php if($results->total_amount >="60000" && $results->total_amount <= "90000" ): ?>
             <!-- 61--90 -->
             <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
            <?php else: ?>
            <td>00</td>
            <?php endif; ?>
            <!-- 91----over -->
            <?php if($results->total_amount >="90000"  ): ?>
            <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
            <?php else: ?>
            <td>00</td>
            <?php endif; ?>
             <!-- total -->
             <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
            
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
          <tr>
            <td><strong>Total</strong></td>
          <?php if(count($result3)>0): ?>
           <td>  PKR <?php echo e(number_format($result3[0]->{'SUM(total_amount)'})); ?>   </td>
<?php else: ?>
<td>00</td>
<?php endif; ?>

<?php if(count($result4)>0): ?>
           <td>  PKR <?php echo e(number_format($result4[0]->{'SUM(total_amount)'})); ?>   </td>
<?php else: ?>
<td>00</td>
<?php endif; ?>
            
<?php if(count($result5)>0): ?>
           <td>  PKR <?php echo e(number_format($result5[0]->{'SUM(total_amount)'})); ?>   </td>
<?php else: ?>
<td>00</td>
<?php endif; ?> 

<?php if(count($result6)>0): ?>
           <td>  PKR <?php echo e(number_format($result6[0]->{'SUM(total_amount)'})); ?>   </td>
<?php else: ?>
<td>00</td>
<?php endif; ?> 

<?php if($total>0): ?>
         
           
          <td>PKR <?php echo e(number_format($total[0]->{'SUM(total_amount)'})); ?> </td>
           
                  <?php endif; ?>
          </tr>
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mss\mss\resources\views/admin/account_payable_print.blade.php ENDPATH**/ ?>
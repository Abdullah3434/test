<?php $__env->startSection('content'); ?>

    
    <!-- page content -->
    <div class="right_col" role="main">
    
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Inventory</h2>
          </div>
        </div>
      </div>
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/inventory" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 

    <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Item</label>
              <select class="form-control" name="item" id="mainCategory" required>
              <option value="" disable="true" selected="true" >---Select Item---</option>
              <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e(urlencode($results->main_category)); ?>"><?php echo e($results->main_category); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

              </select>
            </div>
          </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
           <div class="form-group">
              <label for="sel1">Sub Item</label>
              <select class="form-control" name="sub_item" id="SubCategory" required>
              <option value="" disable="true" selected="true">---Select Sub Item---</option>
              </select>
            </div>
          </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Item Name</label>
                  <input type="text" name="name" class="form-control" id="usr" required>
                </div>
          </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
           <div class="form-group">
                  <label for="usr">UOM(Unit Of Measurement)</label>
                  <input type="text" name="uom" class="form-control" id="usr">
                </div>
          </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Current Stock</label>
                  <input type="text" name="stock" value="0" class="form-control" id="usr">
                </div>
          </div>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
           <div class="form-group">
                  <label for="usr">Opening Balance(PKR)</label>
                  <input type="number" value="0" name="opening_balance" class="form-control" id="usr">
                </div>
          </div>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Description</label>
                  <textarea class="form-control" name="description" rows="9"></textarea>
                </div>
          </div>
    </div>
    </div>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-8">
          <div class="viewadminbtn">
            <button type="submit" class="btnedit btn">Save</button>
          </div>
        </div>
      </div>
    </form>
     </div>
    <!-- /page content --> 
    
   

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/ms/ms/resources/views/admin/add_inventory_view.blade.php ENDPATH**/ ?>
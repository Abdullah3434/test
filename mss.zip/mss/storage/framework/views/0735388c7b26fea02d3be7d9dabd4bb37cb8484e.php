<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="viewadminhead">
        <h2>Create Invoice</h2>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
      <div class="invoicestopright">
        <h4>Invoice #</h4>
        <p><?php echo e($sale_id); ?></p>
      </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="<?php echo e(url('/')); ?>/admin/home/add/customer" class="btn pumpplusbtn" title="Add Supplier"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div>
  </div>
  <form method="post" action ="<?php echo e(url('/')); ?>/admin/home/add/sale/invioce" class="login-form" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Customer Name</label>
            <select class="selectpicker form-control" data-show-subtext="true"  name="customer_name" data-live-search="true" required="required" >
              <option value="" >Select Customer</option>
              
              
                  <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
              
              <option value="<?php echo e($results->pk_id); ?>" ><?php echo e($results->customer_name); ?></option>
              
              
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
      
            
            </select>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
  
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Sale Type</label>
              
              <select class="form-control" id="sale_type" name="sale_type" required>
                 <option value="">Sale Type</option>
                 
                 <option value="sale" >Sale</option>
                 <option value="return">Sale Return</option>
             </select>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Invoice Date</label>
             <input type="text" class="form-control" id="mydate" name="date">
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Due Date</label>
            <input type="text" class="form-control" id="mydate2" name="date2">
          </div>
        </div>
      </div>
    </div>



    
    <div class="container-fluid">
    <div class="field_wrapper">
      <div class="borderrow">
        <div class="row">
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label for="sku">SKU</label>


                <input list="skus" class=" form-control"  id="sku" name="sku[]"  autocomplete="off">
  <datalist id="skus">
  <?php if($inventory>0): ?>
          <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                    
                  <option value="<?php echo e($results->sku); ?>" >
                  
                    
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
  </datalist>


               
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label for="usr">Product/Service</label>


                <input list="names" class=" form-control"   id="name"  name="item_name[]" autocomplete="off">
  <datalist id="names">
  <?php if($inventory>0): ?>
          <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
                    
                  <option value="<?php echo e($results->name); ?>" >
                  
                    
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
  </datalist>

               
            
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>Description</label>
                <input type="text" class="form-control"  name="description[]" >
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>QTY</label>
                <input type="text" class="form-control" id="quantity" name="quantity[]" required>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>Rate</label>
                <input type="text" class="form-control" id="rate" name="rate[]" required>
              </div>
            </div>
          </div>
          
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label for="usr">Amount</label>
                <input type="text" class="form-control" id="amount"  name="amount[]" disabled>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="plusbutton">
                <button type="button" class="add_buttonsale plusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></button>
              </div>
            </div>

            </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
        <div class="totalamounth">
          <h3>Total Amount</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="totalamountp">
          <p id="total">0</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
        <div class="totalamounth">
          <h3>Balance Due</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="totalamountp">
          <p>0</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-9">
        <div class="totalamountp">
          <button type="submit" class="amountbtn btn">Save</button>
        </div>
      </div>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mss\mss\resources\views/admin/add_invoice.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Ms Petroleum">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Ms Petroleum">
<meta name="google-site-verification" content="-3fR2s0fAH-tDmr1Fkt1Zn9Zv3qA3tcabWHX8mpCd28" />
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Ms Petroleum</title>

<!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<!--Custom Styling-->
<link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;"> <a href="index.html" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images/ms logo.png" alt="logo"></i> </a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
            <ul class="nav side-menu">
              <li><a href="index.html"><i class="fa fa-tachometer"></i>Dashboard</a> </li>
              <li><a><i class="fa fa-th-list"></i>Master Modules<span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="view-admin-table.html"><i class="fa fa-list-alt"></i>Admin Management</a></li>
                  <li><a href="view-sub-item-table.html"><i class="fa fa-list-alt"></i>Item Management</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/admin/home/customer/list/view"><i class="fa fa-list-alt"></i>Customer Management</a></li>
                  <li><a href="pumps.html"><i class="fa fa-list-alt"></i>Pump Management</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/admin/home/supplier/list/view"><i class="fa fa-list-alt"></i>Supplier Management</a></li>
                  <li><a href="view-account-table.html"><i class="fa fa-list-alt"></i>Charts of Account</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-th-list"></i>Transactions<span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="view-pump-sale-table.html"><i class="fa fa-list-alt"></i>Pump Sale</a></li>
                  <li><a href="view-pump-purchase-table.html"><i class="fa fa-list-alt"></i>Pump Purchase</a></li>
                  <li><a href="view-sale-table.html"><i class="fa fa-list-alt"></i>Sale Management</a></li>
                  <li><a href="view-purchase-table.html"><i class="fa fa-list-alt"></i>Purchase Management</a></li>
                  <li><a href="account-payable.html"><i class="fa fa-list-alt"></i>Account Payable (A/P)</a></li>
                  <li><a href="account-receivable.html"><i class="fa fa-list-alt"></i>Account Receivable (A/R)</a></li>
                  <li><a href="view-expenses-table.html"><i class="fa fa-list-alt"></i>Expense Management</a></li>
                  <li><a href="#"><i class="fa fa-list-alt"></i>Transfer Of Money</a></li>
                </ul>
              </li>
              <li><a href="view-inventory-table.html"><i class="fa fa-th-list"></i>Inventory Management</a> </li>
              <li><a href="view-zakat-table .html"><i class="fa fa-th-list"></i>Zakat Module</a></li>
              <li><a><i class="fa fa-th-list"></i>Kachi Parchi Module</a> </li>
              <li><a><i class="fa fa-th-list"></i>Other Income</a> </li>
              <li><a><i class="fa fa-th-list"></i>Tanker</a> </li>
              <li><a><i class="fa fa-th-list"></i>Shortage Excess</a> </li>
              <li><a href="view-material-table.html"><i class="fa fa-th-list"></i>Purchase Module</a></li>
              <li><a><i class="fa fa-th-list"></i>Reports<span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="reports.html"><i class="fa fa-list-alt"></i>Report</a></li>
                  <li><a href="view-sale-table(reports).html"><i class="fa fa-list-alt"></i>Sale Report</a></li>
                  <li><a href="view-purchase-table(reports).html"><i class="fa fa-list-alt"></i>Purchase Report</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu --> 
      </div>
    </div>
    
    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="#" alt="">MS Petroleum <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="<?php echo e(url('/')); ?>/admin/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation --> 

<?php echo $__env->yieldContent('content'); ?> 
  
  <!-- footer content -->
  <footer>
      <div class="footersets">
        <p>Copyright © 2018-2019 Green Grapez. All rights reserved. </p>
        <br>
        <span>Powered By<a href="http://greengrapez.com/"> <img src="<?php echo e(url('/')); ?>/images/icon.png" style="width:50px;" alt="po"></a></span> </div>
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div>

<!-- jQuery --> 
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script> 
<!-- DateJS --> 
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script> 
<!-- bootstrap-progressbar --> 
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script> 
<!-- iCheck --> 
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script> 
<!-- bootstrap-daterangepicker --> 
<script src="<?php echo e(url('/')); ?>/js/moment.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/daterangepicker.js"></script> 
<!-- Custom Theme Scripts --> 
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MS-petroleum\resources\views/admin/layout/appadmin.blade.php ENDPATH**/ ?>
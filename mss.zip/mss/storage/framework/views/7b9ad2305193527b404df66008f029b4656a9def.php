<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12">
          <div class="viewadminhead">
            <h2>Reports</h2>
          </div>
        </div>
      </div>
      <div class="content-wrapper">
        <div class="container-fluid">
          <div class="row"> 
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="reportboxouter"> 
               <a href="profit&loss-report.html">
              <div class="reportbox"> 
            
         <h4>Profit & Loss</h4>
          </div>
          </a>
           </div>
         
          </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
              <div class="reportboxouter">
             <a href="<?php echo e(url('/')); ?>/admin/home/view/account/receivable">
              <div class="reportbox"> 
            
         <h4>Account Receivable</h4>
          </div>
          </a>
         </div>
          </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
              <div class="reportboxouter">
          <a href="<?php echo e(url('/')); ?>/admin/home/view/account/payable">
              <div class="reportbox"> 
            
         <h4>Account payable</h4>
          </div>
          </a>
          </div>
          
          </div>
          
         
          </div>
         <div class="row"> 
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="reportboxouter"> 
               <a href="trial-balance.html">
              <div class="reportbox"> 
            
         <h4>Trial Balance</h4>
          </div>
          </a>
           </div>
         
          </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
              <div class="reportboxouter">
             <a href="general-ledger-table-PA.html">
              <div class="reportbox"> 
            
         <h4>General Ledger</h4>
          </div>
          </a>
         </div>
          </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
              <div class="reportboxouter">
          <a href="daybook1.html">
              <div class="reportbox"> 
            
         <h4>DayBook</h4>
          </div>
          </a>
          </div>
          
          </div>
          
         
          </div>
          <div class="row"> 
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
               <div class="reportboxouter"> 
               <a href="balance-sheet.html">
              <div class="reportbox"> 
            
         <h4>Balance Sheet</h4>
          </div>
          </a>
           </div>
         
          </div>
            
          
         
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/report_list_view.blade.php ENDPATH**/ ?>
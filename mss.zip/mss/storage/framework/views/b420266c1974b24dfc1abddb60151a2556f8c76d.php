
<?php $__env->startSection('content'); ?>
    
<form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/sale/<?php echo e($result1[0]->pk_id); ?>" class="login-form" enctype="multipart/form-data">
                   
                   <?php echo e(csrf_field()); ?>

              
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Edit Sale</h2>
          </div>
        </div>

         <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
         
          <div class="invoicestopright">
          <h4>Sale Invoice #</h4>
           <p><?php echo e($result1[0]->pk_id); ?></p>
          </div>
        
         </div>
      </div>
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Customer Name</label>
                  <select class="form-control" id="customer_name" name="customer_name">
                  <option value="">Select Customer</option>
                 
                  <?php if($customer>0): ?>
          <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($results->pk_id); ?>" <?php if($results->pk_id == $result1[0]->customer_name): ?> selected <?php endif; ?> ><?php echo e($results->customer_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </select>
                </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Account Type</label>
              <select class="form-control" id="" name="account_type">
                <option value="cash" <?php if($result1[0]->account_type == 'cash'): ?> selected <?php endif; ?>>Cash</option>
                <option value="credit" <?php if($result1[0]->account_type == 'credit'): ?> selected <?php endif; ?>>Credit (A/P)</option>
              </select>
            </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Sale Type</label>
                  <select class="form-control" id="" name="sale_type">
                <option value="sale" <?php if($result1[0]->sale_type == 'sale'): ?> selected <?php endif; ?>>Sale</option>
                <option value="sale return" <?php if($result1[0]->sale_type == 'sale return'): ?> selected <?php endif; ?>>Sale Return</option>
              </select>
                </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Company Name</label>
                  <input type="text" value="<?php echo e($result1[0]->company_name); ?>" class="form-control" id="" name="company_name">
                </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Vehicle No</label>
                  <input type="text" class="form-control" id="" value="<?php echo e($result1[0]->vehicle_no); ?>" name="vehicle_no">
                </div>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
         
         <div class="invoicestopright">
         <h4>Bills #</h4>
          <p id="bills"><?php echo e($result1[0]->customer_name); ?></p>
         </div>
       
        </div>
      <?php if(count($result)>0): ?>
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="container-fluid">
        
             <div class="field_wrapper">
               <div class="borderrow">
           <div class="row">
          
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">SKU</label>
                  <select class="form-control" id="sku" name="sku[]">
                  <option value="">Select Item SKU</option>
                  <?php if($inventory>0): ?>
          <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($inventories->sku); ?>" <?php if($inventories->sku == $results->sku): ?> selected <?php endif; ?>><?php echo e($inventories->sku); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              </select>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Item Name</label>
                  <input type="text" class="form-control" name="item_name[]" value="<?php echo e($results->item_name); ?>" id="name">
                </div>
              </div>
            </div>
           
          
             <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Quantity</label>
                  <input type="text" class="form-control" value="<?php echo e($results->quantity); ?>" id="quantity" name="quantity[]" >
                </div>
              </div>
            </div>
             <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Rate</label>
                  <input type="text" class="form-control" id="rate" name="rate[]" value="<?php echo e($results->rate); ?>" >
                </div>
              </div>
               
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
            <div class="form-group">
              <label for="usr">Amount</label>
              <input type="text" class="form-control" id="amount" value="<?php echo e($results->amount); ?>" name="amount[]" disabled>
            </div>
          </div>
           
        </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="plusbutton">
                <button class="add_buttonsale plusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></button>
              </div>
            </div>
          </div>
          </div>
        </div>
         </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
          <div class="totalamounth">
            <h3>Total Amount</h3>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="totalamountp">
            <p id="total"><?php echo e($result1[0]->total_amount); ?></p>
          </div>
        </div>
      </div>
   
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-9">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
     
      </div>
    </div>
    </form>
    <!-- /page content --> 
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/new_adil/mspetroleum/resources/views/admin/edit_sale_view.blade.php ENDPATH**/ ?>
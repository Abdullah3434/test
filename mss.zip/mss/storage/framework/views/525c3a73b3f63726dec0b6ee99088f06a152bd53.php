
<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Sale return/ By Customer</h2>
          </div>
        </div>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <div class="machinename">
         <h4><?php echo e($result1[0]->billing_address); ?></h4>
         </div>
        </div>
      </div>
      <div class="row">
       <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Customer Name :</h4>
          <p><?php echo e($result1[0]->customer_name); ?></p>
         </div>       
      </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Balance :</h4>
          <p>PKR <?php echo e(number_format($result1[0]->opening_balance)); ?></p>
         </div>       
      </div>
     
        
  
      
       <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Total Sale Return:</h4>
          <p>PKR <?php echo e(number_format($total_amount[0]->{'SUM(total_amount)'})); ?></p>
         </div>       
      </div>
      
      </div>
      
      
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor">
                  <tr>
                    <th>D-Invoice</th>
                    <th>Company Name</th>
                        <th>Vehicle No</th>
                        <th>Bills #</th>
                        <th>Account Type</th>
                         <th>Sale Type</th>
                          <th>Amount</th>
                            <th>Date</th>
                             <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                   <td><?php echo e($results->pk_id); ?></td>
                     <td><?php echo e($results->company_name); ?></td>
                      <td><?php echo e($results->vehicle_no); ?></td>
                      <td>001</td>
                      <td><?php echo e($results->account_type); ?></td>
                    <td><?php echo e($results->sale_type); ?></td>
                     <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
                      <td><?php echo e($results->created_at); ?></td>
                        <td><a href="<?php echo e(url('/')); ?>/admin/home/view/sale/return/detail/<?php echo e($results->pk_id); ?>" class="bordersets">view</a>  &nbsp;&nbsp;&nbsp;<a href="#"><i class="fa fa-print sizecol"></i></a></td>
                            
                  </tr>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
                
              
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/view_sale_return_list.blade.php ENDPATH**/ ?>
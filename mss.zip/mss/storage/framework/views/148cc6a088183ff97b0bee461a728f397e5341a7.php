<?php $__env->startSection('content'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Purchases / <?php echo e($supplier[0]->supplier_name); ?></h2>
          </div>
        </div>
      </div>
      <div class="row">
     
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>PI # :</h4>
          <p><?php echo e($result1[0]->pk_id); ?></p>
         </div>       
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>STI # :</h4>
          <p><?php echo e($result1[0]->sti); ?></p>
         </div>       
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>D-Invoice :</h4>
          <p><?php echo e($supplier[0]->pk_id); ?></p>
         </div>       
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>Billing Address :</h4>
          <p><?php echo e($supplier[0]->billing_address); ?></p>
         </div>       
      </div>
  
      
       <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>Company Name :</h4>
          <p><?php echo e($result1[0]->company_name); ?></p>
         </div>       
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>Vehical# :</h4>
          <p><?php echo e($result1[0]->vehicle_no); ?></p>
         </div>       
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead" style="margin-top:10px;">
         <h4>Date :</h4>
          <p><?php echo e($result1[0]->created_at); ?></p>
         </div>       
      </div>
       <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
         <div class="buttonright">
         <a href="<?php echo e(url('/')); ?>/admin/home/edit/purchase/<?php echo e($result1[0]->pk_id); ?>" class="editrightbtn btn">Edit</a>
         </div>       
      </div>
      
      </div>
      
      
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <?php if($purchase == "kachi parchi"): ?>
                <thead class="headbgcolor">
                  <tr>
                    <th>SKU</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                     <th>Rate</th>
                     
                      <th>Total Price</th>
                        
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td><?php echo e($results->sku); ?></td>
                      <td><?php echo e($results->item_name); ?></td>
                     <td><?php echo e($results->quantity); ?> L</td>
                    <td>PKR <?php echo e(number_format($results->rate)); ?></td>
                 
                    <td>PKR <?php echo e(number_format($results->amount)); ?></td>
                    
                            
                  </tr>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
                
                
              
                </tbody>
                <?php else: ?>
                <thead class="headbgcolor">
                  <tr>
                    <th>SKU</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                     <th>Rate</th>
                     <th>Amount Exclusive Tax</th>
                     <th>Tax</th>
                     <th>Tax amount</th>
                     <th>Amount Inclusive Tax</th>
                        
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td><?php echo e($results->sku); ?></td>
                      <td><?php echo e($results->item_name); ?></td>
                     <td><?php echo e($results->quantity); ?> L</td>
                    <td>PKR <?php echo e(number_format($results->rate)); ?></td>
                    <td>PKR <?php echo e(number_format($results->rate * $results->quantity)); ?></td>
                    <td><?php echo e($results->tax); ?>%</td>
                    <td>PKR <?php echo e(number_format($results->tax_amount)); ?></td>
                    <td>PKR <?php echo e(number_format($results->amount)); ?></td>
                    
                            
                  </tr>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
              
                </tbody>
                <?php endif; ?>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
          <div class="totalamounth">
            <h3>Total</h3>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="totalamountp">
            <p>PKR <?php echo e(number_format($result1[0]->total_amount)); ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/ms/ms/resources/views/admin/purchase_detail_view.blade.php ENDPATH**/ ?>
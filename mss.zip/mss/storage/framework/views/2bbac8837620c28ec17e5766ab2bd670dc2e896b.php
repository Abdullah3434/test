
<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Machine</h2>
          </div>
        </div>
      </div>
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/machine/<?php echo e($result[0]->pk_id); ?>" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Pump Name</label>
            
                  <input type="text" class="form-control" value="<?php if(count($result1)>0): ?> <?php echo e($result1[0]->pump_name); ?>  <?php endif; ?>" name="pump_name">
                
                </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Tank Name</label>
              <select class="form-control" id="" name="tank_name">
              <?php if(count($result2)>0): ?>
              <?php $__currentLoopData = $result2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($results->pk_id); ?>" <?php if($result[0]->tank_id == $results->pk_id): ?> selected <?php endif; ?>><?php echo e($results->tank_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
               
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="field_wrapper ">
          <div class="borderrow">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Machine Name</label>
                  <input type="text" class="form-control" value="<?php echo e($result[0]->machine_name); ?>" id="usr" name="machine_name">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Closing Reading</label>
                  <input type="text" class="form-control" id="usr" value="<?php echo e($result[0]->closing_reading); ?>" name="closing_reading">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Rate</label>
                  <input type="text" class="form-control" id="" value="<?php echo e($result[0]->rate); ?>"  name="rate">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Current Dip</label>
                  <input type="text" class="form-control" value="<?php echo e($result[0]->current_dip); ?>" id="" name="current_dip">
                </div>
              </div>
            </div>
            <!-- <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="plusbutton">
                <button href="javascript:void(0);" class="add_buttonmachine plusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></button>
              </div>
            </div> -->
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-7">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>
      </form>
    </div>
    <!-- /page content --> 
    
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/edit_machine_view.blade.php ENDPATH**/ ?>
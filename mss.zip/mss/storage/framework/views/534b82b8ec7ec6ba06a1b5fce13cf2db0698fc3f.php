<?php $__env->startSection('content'); ?>
    

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Account Receivable</h2>
          </div>
        </div>
      </div>

      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/account/receivable" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?>

      <div class="row">
        <!--<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">-->
        <!--  <div class="createadmininputs">-->
        <!--    <div class="form-group">-->
        <!--          <label for="usr">Customer Name</label>-->
        <!--          <select class="form-control" id="account_receivable" name="customer_name">-->
        <!--          <option value="">Select Customer</option>-->
        <!--          <?php if($result>0): ?>-->
        <!--        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
        <!--        <option value="<?php echo e($results->pk_id); ?>"><?php echo e($results->customer_name); ?></option>-->
        <!--        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
        <!--                  <?php endif; ?>-->
        <!--      </select>-->
        <!--        </div>-->
        <!--  </div>-->
        <!--</div>-->
        
        
           <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Customer Name</label>

<select class="selectpicker form-control" data-show-subtext="true" name="customer_name" data-live-search="true" >
                <option  class="form-control" >Select Customer</option>
                  <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option class="form-control"  value="<?php echo e($results->pk_id); ?>" ><?php echo e($results->customer_name); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
      </select>



                </div>
                
               
          </div>
        </div>
        
        
        
         <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Amount Receivable</label>
                  <input type="text" class="form-control" value="0" id="amount_receivable" name="amount_receivable">
                </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Date</label>
                  <input type="date" class="form-control" id="" name="date">
                </div>
          </div>
        </div>
         
         
      </div>
     <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Amount Received</label>
                  <input type="text" class="form-control" id="" name="amount_received">
                </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Receiving Method</label>
              <select class="form-control" id="" name="receiving_method">
                <option value="bank">Bank</option>
                <option value="cash">Cash</option>
              </select>
            </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Receiving Account</label>
              <select class="selectpicker form-control" required="" data-show-subtext="true" name="account_type" id=" " data-live-search="true">
                  <?php foreach ($account_type as $key => $value) {
             
                ?>
                <option  class="form-control"  value="<?php echo e($value->pk_id); ?>" ><?php echo e($value->account_name); ?></option>
              
              <?php } ?>
              </select>
            </div>
          </div>
        </div>
        
          
      </div>
      
     
        
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-4">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>
      </form>
    </div>
    <!-- /page content --> 
  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ms\mspetroleum\resources\views/admin/add_account_receivable_view.blade.php ENDPATH**/ ?>
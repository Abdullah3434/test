<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Machine</h2>
          </div>
        </div>
      </div>
      <?php if(isset($result1) && !empty($result1)) { ?>
            <?php if(count($result1)>0): ?>
      <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Adminprofilebox">
          <div class="row">
           <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
           <div class="viewpumphead">
           <h3>Tank Info/Detail</h3>
           </div>
          </div>
           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
             <div class="viewpumpbtn">
                    <a href="<?php echo e(url('/')); ?>/admin/home/edit/tank/<?php echo e($results->pk_id); ?>" class="btnedit btn">Edit</a>
                  </div>
          </div>
          </div>
          
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Tank Name</h4>
                   <p><?php echo e($results->tank_name); ?></p>
                </div>
              </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Total Capacity</h4>
                   <p><?php echo e($results->total_capacity); ?></p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Total Dip</h4>
                   <p><?php echo e($results->total_dip); ?></p>
                </div>
            </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Opening Stock</h4>
                   <p><?php echo e($results->opening_stock); ?></p>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Unit Of Measurement</h4>
                   <p><?php echo e($results->uom); ?></p>
                </div>
              </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Opening Balance</h4>
                   <p>PKR <?php echo e(number_format($results->opening_balance)); ?></p>
                </div>
            </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Opening Dip</h4>
                   <p><?php echo e($results->opening_dip); ?></p>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
         <?php if(count($result)>0): ?>
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Adminprofilebox">
          <div class="row">
           <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
           <div class="viewpumphead">
           <h3>Machine Info/Detail</h3>
           </div>
          </div>
           <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
             <div class="viewpumpbtn">
                     <a href="<?php echo e(url('/')); ?>/admin/home/edit/machine/<?php echo e($results->pk_id); ?>" class="btnedit btn">Edit</a>
                  </div>
          </div>
          </div>
          
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Current Dip</h4>
                   <p><?php echo e($results->current_dip); ?></p>
                </div>
              </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Machine Name</h4>
                   <p><?php echo e($results->machine_name); ?></p>
                </div>
            </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Closing Reading</h4>
                   <p><?php echo e($results->closing_reading); ?></p>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="viewexpenselines">
                  <h4>Rate</h4>
                   <p>PKR <?php echo e(number_format($results->rate)); ?></p>
                </div>
              </div>
               <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              
            </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              
              </div>
            </div>
            </div>
          </div>
        </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php } else ?>
        <h3>No record found</h3>
        <?php ?>
         
    <!-- /page content --> 
    <?php $__env->stopSection(); ?>
   
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/machine_detail_view.blade.php ENDPATH**/ ?>
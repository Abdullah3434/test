<?php $__env->startSection('content'); ?>

    
    <!-- page content -->
    <div class="right_col" role="main">
    
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Item</h2>
          </div>
        </div>
      </div>
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/main/category" class="login-form">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
    <div class="row">
    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
      <div class="createadmininputs">
           <div class="form-group">
                  <label for="usr">Item</label>
                  <input type="text" name="mainCategory"  class="form-control" id="">
                </div>
          </div>
    </div>
    </div>
    
      <div class="row">
       <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="editpart">
            <button type="submit" class="btnedit btn">Save</button>
          </div>
        </div>
      </div>
    </form>
     </div>
    <!-- /page content --> 
    
   
          <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/add_main_category_view.blade.php ENDPATH**/ ?>
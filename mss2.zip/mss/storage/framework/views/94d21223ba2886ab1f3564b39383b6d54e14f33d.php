<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Pumps</h2>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="<?php echo e(url('/')); ?>/admin/home/add/pump" class="btn pumpplusbtn" title="Add Pump"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div>
      </div>

      <div class="row">
                <?php if(count($result)>0): ?>
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> <a href="<?php echo e(url('/')); ?>/admin/home/view/machine/<?php echo e($results->pk_id); ?>">
          <div class="pumpbox">
            <div class="pumpboxlines">
              <h4>Pump Name</h4>
              <p><?php echo e($results->pump_name); ?></p>
              <h4>Address :</h4>
              <p><?php echo e($results->pump_address); ?></p>
            </div>
          </div>
          </a> 
          <div class="col-lg-6">
            <a href="<?php echo e(url('/')); ?>/admin/home/edit/pump/<?php echo e($results->pk_id); ?>" class="btn pumpplusbtn" title="Edit Pump" style="float:left"><span class="glyphicon glyphicon-pencil"></span></a>
          </div>
          <div class="col-lg-6">
            <a href="#" onclick="getId(this.id)"  data-toggle="modal" data-target="#myModal<?php echo e($results->pk_id); ?>" class="btn pumpplusbtn" title="Delete Pump"><span class="glyphicon glyphicon-trash"></span></a>
          </div>
          </div>
          

                    <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo e($results->pk_id); ?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Confirmation Message</h4>
        </div>
        <div class="modal-body">
          <p>You are about to delete <b><i class="title"></i></b> record, this procedure is irreversible.</p>
                    <p>Do you want to proceed?</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
          <a href="<?php echo e(url('/')); ?>/admin/home/delete/pump/<?php echo e($results->pk_id); ?>" class="btn btn-danger">Yes</a>
        </div>
      </div>
      
    </div>
  </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
      </div>
    </div>
  
  <!-- /page content --> 
  


  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/pump_list_view.blade.php ENDPATH**/ ?>
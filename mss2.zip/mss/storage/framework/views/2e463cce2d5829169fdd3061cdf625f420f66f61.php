<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Purchases / By Supplier</h2>
          </div>
        </div>
        
      </div>
      <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Billing Address :</h4>
          <p><?php echo e($result1[0]->billing_address); ?></p>
         </div>       
      </div>
       <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Supplier Name :</h4>
          <p><?php echo e($result1[0]->supplier_name); ?></p>
         </div>       
      </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Balance :</h4>
          <p>PKR <?php echo e(number_format($result1[0]->opening_balance)); ?></p>
         </div>       
      </div>
     
        
  
      
       <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
         <div class="Totalpurchasehead">
         <h4>Total Purchases :</h4>
          <p>PKR <?php echo e(number_format($total_amount[0]->{'SUM(total_amount)'})); ?></p>
         </div>       
      </div>
      
      </div>
      
      
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor">
                  <tr>
                    <th>PI #</th>
                        <th>D-Invoice</th>
                    <th>STI #</th>
                    <th>Purchase Type</th>
                        <th>Account Type</th>
                         <th>Qty</th>
                          <th>Amount</th>
                    <th>Company Name</th>
                        <th>Vehicle No</th>
                            <th>Date</th>
                             <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
               
                $total_q1 = DB::select("select SUM(quantity) from detail_purchase where purchase_id = '$results->pk_id'");
                $total_q2 = DB::select("select SUM(quantity) from detail_tax_purchase where purchase_id = '$results->pk_id'");
             
                ?>
                   <tr>
                   <td><?php echo e($results->pk_id); ?></td>
                   
                      <td><?php echo e($result1[0]->pk_id); ?></td>
                   <td><?php echo e($results->sti); ?></td>
                   <?php if($results->purchase == "tax"): ?>
                   <td>Tax</td>
                   <?php else: ?>
                   <td>Normal</td>
                   <?php endif; ?>
        
                  <?php $account_type= DB::table('account')->where('pk_id',$results->account_type)->first();
                        if(empty($account_type)){ ?>
                         
                      <td><?php echo e($results->account_type); ?></td>

                  <?php }else{ ?>

                         <td><?php echo e($account_type->account_name); ?></td>
                         
                   <?php } ?>

                        <?php if($results->purchase == "tax"): ?>
                   <td><?php echo e(number_format($total_q2[0]->{'SUM(quantity)'})); ?></td>
                   <?php else: ?>
                   <td><?php echo e(number_format($total_q1[0]->{'SUM(quantity)'})); ?></td>
                   <?php endif; ?>
                     <td>PKR <?php echo e(number_format($results->total_amount)); ?></td>
                     <td><?php echo e($results->company_name); ?></td>
                      <td><?php echo e($results->vehicle_no); ?></td>
                      <td><?php echo e($results->created_at); ?></td>
                        <td><a href="<?php echo e(url('/')); ?>/admin/home/view/purchase/detail/<?php echo e($results->pk_id); ?>/<?php echo e($results->purchase); ?>" class="bordersets">view</a>  &nbsp;&nbsp;&nbsp;<a href="#"><i class="fa fa-print sizecol"></i></a></td>
                            
                  </tr>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
                
              
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/new_adil/mspetroleum/resources/views/admin/view_purchase_list.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?> 
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Edit Tank</h2>
          </div>
        </div>
      </div>
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/tank/<?php echo e($result[0]->pk_id); ?>" class="login-form" enctype="multipart/form-data">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Pump Name</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result1[0]->pump_name); ?>" name = "pump_name">
                </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1">
          <div class="createadmininputs">
             <div class="form-group">
                  <label for="usr">Pump Address</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result1[0]->pump_address); ?>" name = "pump_address">
                </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="field_wrapper">
          <div class="borderrow">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Tank Name</label>
                  <input type="text" class="form-control" value= "<?php echo e($result[0]->tank_name); ?>" id="usr" name="tank_name">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Total Capacity</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result[0]->total_capacity); ?>" name="total_capacity">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Opening Stock</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result[0]->opening_stock); ?>" name="opening_stock">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Unit Of Measurement</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result[0]->uom); ?>"  name="uom">
                </div>
              </div>
            </div>
             <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Opening Balance</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result[0]->opening_balance); ?>"  name="opening_balance">
                </div>
              </div>
            </div>
             <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Opening Dip</label>
                  <input type="text" class="form-control" id="" value= "<?php echo e($result[0]->opening_dip); ?>"  name="opening_dip">
                </div>
              </div>
                 <!-- <div class="plusbutton">
                <button href="javascript:void(0);" class="add_button2 plusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></button>
              </div> -->
            </div>
         
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-9">
          <div class="totalamountp">
            <button href="#" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>

      </form>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/edit_tank_view.blade.php ENDPATH**/ ?>
    <?php $__env->startSection('content'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Trial Balance</h2>
          </div>
        </div>
      </div>
      
      
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Adminprofilebox">
            <div class="row">
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="accountpayablehead">
             <h4>Trial Balance</h4>
             <!-- <p>January 1-Faburary 10</p> -->
             </div>
             </div>
            
            </div>
            
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor2">
                  <tr>
                    <th></th>
                    <th>Debit</th>
                    <th>Credit </th>
                   
                    
                    
                  </tr>
                </thead>
                <tbody>
                <tbody>
              
                  <tr>
                    <td >Sale </td>
                    <td>000</td>
                     <td><?php echo e(number_format($sale_inc)); ?></td>
                     
                   
                  </tr>
                
                
                
       
               
                  <tr>
                  <td>Cash in Hand</td>
                  
                     <td><?php echo e(number_format($coh_inc)); ?></td>

                    
            <td>000</td>
        
                   
                   
                  </tr>
                 
                  <tr>
                  <td>Account Reciveable</td>
                  <td><?php echo e(number_format($lib_inc)); ?></td>
                  <td>000</td>
                   
                    
                   
                  </tr>
                
                  <?php if($detail_purchase>0): ?>
         
                  <tr>
                  <td>Account payable</td>
                  <td>000</td>
                     <td><?php echo e(number_format($detail_purchase_sum)); ?></td>
                     
                   
                  </tr>
                 
                  <?php endif; ?>


                  <?php if($Capital>0): ?>
          <?php $__currentLoopData = $Capital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($results->account_name); ?></td>
                  <td>000</td>
                     <td><?php echo e(number_format($Capital_inc)); ?></td>
                    
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>


                  <?php if($Capital_sub>0): ?>
          <?php $__currentLoopData = $Capital_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($results->sub_account); ?></td>
                  <td>000</td>
                     <td><?php echo e(number_format($Capital_sub_inc)); ?></td>
                    
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                  <?php if($Capital_sub_decrease>0): ?>
          <?php $__currentLoopData = $Capital_sub_decrease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                 
                  <td><?php echo e($results->sub_account); ?></td>
                  
                     <td><?php echo e(number_format($Capital_sub_dec)); ?></td>
                    
                     <td>000</td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                  <?php if($detail_purchase>0): ?>
          <?php $__currentLoopData = $detail_purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                  <td><?php echo e($results->item_name); ?></td>
                 
                     <td><?php echo e(number_format($results->amount)); ?></td>
                     <td>000</td>
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>



                  <!-- <?php if($detail_purchase>0): ?>
         
                  <tr>
                  <td>Cash in hand</td>
                  <td>000</td>
                     <td><?php echo e($detail_purchase_sum); ?></td>
                     
                   
                  </tr>
                 
                  <?php endif; ?> -->


                </tbody>
              </table>
           <div class="row">
           <div class="col-lg-7 col-md-9 col-sm-12 col-xs-12">
            <div class="totalpayabletable">
            <h4>Total</h4>
           </div>
           </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="totalpayabletable">
             
            <p>PKR <?php echo e(number_format(($total_amount2)+
           
            +($detail_purchase_sum)+($lib_inc)+($Capital_sub_dec))); ?></p>
           
           </div>
           </div>
           <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
             <div class="totalpayabletable">
            
            <p>PKR <?php echo e(number_format(($total_amount)+($pur_inc)+($detail_purchase_sum)+($Capital_inc)+($Capital_sub_inc))); ?></p>
           
           </div>
           </div>
           </div>
          
           
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mss\resources\views/admin/trial_balance.blade.php ENDPATH**/ ?>
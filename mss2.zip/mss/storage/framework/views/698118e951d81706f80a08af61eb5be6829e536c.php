<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Pumps</h2>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="<?php echo e(url('/')); ?>/admin/home/add/pump" class="btn pumpplusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div>
      </div>
      <div class="row">
          
      <?php if(count($result)>0): ?>
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> <a href="<?php echo e(url('/')); ?>/admin/home/view/pump/purchase/by/supplier/<?php echo e($results->pk_id); ?>">
          <div class="pumpbox">
            <div class="pumpboxlines">
              <h4>Pump Name</h4>
              <p><?php echo e($results->pump_name); ?></p>
              <h4>Address :</h4>
              <p><?php echo e($results->pump_address); ?></p>
            </div>
          </div>
          </a> </div>
          
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
      </div>
    </div>
  
  <!-- /page content --> 
  


  
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mss\mss\resources\views/admin/pump_for_purchase_list_view.blade.php ENDPATH**/ ?>
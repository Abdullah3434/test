
<?php $__env->startSection('content'); ?> 
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Pump</h2>
          </div>
        </div>
      </div>
      <?php if(count($result)>0): ?>
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/pump/<?php echo e($result[0]->pk_id); ?>" class="login-form" enctype="multipart/form-data">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Pump Name</label>
                  <input type="text" class="form-control" id="" value="<?php echo e($result[0]->pump_name); ?>" name = "pump_name">
                </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1">
          <div class="createadmininputs">
             <div class="form-group">
                  <label for="usr">Pump Address</label>
                  <input type="text" class="form-control" id="" value="<?php echo e($result[0]->pump_address); ?>" name = "pump_address">
                </div>
          </div>
        </div>
      </div>
   
      
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-9">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>

      </form>
      <?php endif; ?>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/new_adil/mspetroleum/resources/views/admin/edit_pump_view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Bank Deposit</h2>
          </div>
        </div>
      </div>

      
      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/bank/deposit" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>



                   <?php if($errors->any()): ?>
             
             <div class="alert alert-success">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 

      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Account</label>
                  <select class="form-control selectpicker" name="bank_account" data-show-subtext="true" data-live-search="true">
                  <option value=""> </option>
                  <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($results->account_name); ?>"><?php echo e($results->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
      </select>
                </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-1">
          <div class="createadmininputs">
             <div class="form-group">
                  <label for="usr">Date</label>
                  <input type="text" class="form-control" id="mydate" name="date">
                </div>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="borderrow">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Received From</label>
                 
                 
                  <select class="form-control selectpicker"  data-show-subtext="true" name="recive_from" data-live-search="true">
                  <option value=""> </option>
                  <?php if($result1>0): ?>
          <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($results->customer_name); ?>"><?php echo e($results->customer_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
      </select>
     
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Account Type</label>
                  
                  <select class="form-control selectpicker" data-show-subtext="true" name="main_acc" data-live-search="true">
                  <option value=""> </option>
                  <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($results->pk_id); ?>"><?php echo e($results->account_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
      </select>
     
                </div>
              </div>
            </div>



            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr"> Account Name</label>
                  
                  <select class="form-control selectpicker" data-show-subtext="true" name="account_type" data-live-search="true">
                  <option value=""> </option>
                  <?php if($sub_account>0): ?>
          <?php $__currentLoopData = $sub_account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($results->pk_id); ?>"> <?php echo e($results->sub_account); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
      </select>
     
                </div>
              </div>
            </div>




            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Description</label>
                  <input class="form-control" name="description" >
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Payment Method</label>
                  <select class="form-control selectpicker" name="method" data-show-subtext="true" data-live-search="true">
                  <option value=""> </option>
        <option >Cash</option>
       
      </select>
                </div>
              </div>
            </div>
             <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Amount</label>
                  <input type="number" name = "amount" class="form-control">
                </div>
              </div>
            </div>
         
          </div>
      </div>
      
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-9">
          <div class="totalamountp">
            <button type="submit"  class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>
</form>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ms\mspetroleum\resources\views/admin/create_bank_deposit.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
      <div class="viewadminhead">
        <h2>Receive Payment</h2>
      </div>
    </div>
  </div>
  <?php if($result1>0): ?>
          <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form method="post" action ="<?php echo e(url('/')); ?>/admin/home/create/sale_invoice/payment/<?php echo e($results->pk_id); ?>" class="login-form" enctype="multipart/form-data">
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
    
    <?php echo e(csrf_field()); ?>

    
    <?php if($errors->any()): ?>
    <div class="alert alert-success"> <strong></strong> <?php echo e($errors->first()); ?> </div>
    <?php endif; ?>
    
     
    
    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Customer Name</label>
            <select class="selectpicker form-control" data-show-subtext="true" name="customer_name" data-live-search="true">
             
              
              
                  <?php if($customer2>0): ?>
          <?php $__currentLoopData = $customer2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
              
              <option  class="form-control"  value="<?php echo e($results->customer_name); ?>" ><?php echo e($results->customer_name); ?></option>
              
              
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
      
            
            </select>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Payment Date</label>
            <input type="text" class="form-control" id="mydate" name="date">
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Payment Method</label>
            <select class="selectpicker form-control" data-show-subtext="true" id="Cash" name="account_type" data-live-search="true">
                <option  class="form-control" >Account Type</option>
              
        <option    value="cash" >Cash</option>
        <option    value="credit" >Credit</option>
       
      </select>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
          <div class="form-group">
            <label for="usr">Deposit To</label>
            
            <select class="selectpicker form-control" data-show-subtext="true" name="deposit_to" data-live-search="true">
              <option  class="form-control" >Select Deposit to</option>
              
              
                  <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
              
              <option  class="form-control"  value="<?php echo e($results->pk_id); ?>" ><?php echo e($results->customer_name); ?></option>
              
              
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
       
      
            
            </select>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
      <div class="borderrow">
        <div class="row">
        <?php if($result1>0): ?>
          <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label for="usr">Description</label>
                <input type="text" class="form-control" value="<?php echo e($results->pk_id); ?>Invoice<?php echo e($results->bill_date); ?>" name="description" readonly>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label for="usr">Due Date</label>
                <input type="date" class="form-control"  value="<?php echo e($results->due_date); ?>"  name="due_date" readonly>
              </div>
            </div>
          </div>
         
         

          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>Orignal Amount</label>
                <input type="text" class="form-control"  value="<?php echo e($results->total_amount); ?>"  name="org_amount" readonly>
              </div>
            </div>
          </div>
         
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>Open Balance</label>
                
                <input type="text" class="form-control" value="<?php echo e($new_total); ?>" name="" readonly>
               

              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
            <div class="createadmininputs">
              <div class="form-group">
                <label>Payment</label>
                <input type="text" class="form-control"  value="<?php echo e($results->total_amount); ?>" name="partial" >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
        <div class="totalamounth">
          <h3>Amount to apply</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="totalamountp">
          <p id="total">0</p>
        </div>
      </div>
    </div>
    <!-- <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-6">
        <div class="totalamounth">
          <h3>Amount to credit</h3>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="totalamountp">
          <p>0</p>
        </div>
      </div>
    </div> -->
    <div class="row">
        <div class="col-lg-6 col-md-3 col-sm-12 col-xs-12">
        <div class="createadmininputs">
              <div class="form-group">
                <label>Memo</label>
                <textarea class="form-control" rows="5" name=""></textarea>
              </div>
            </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-3">
        <div class="totalamountp">
          <button type="submit" class="amountbtn btn">Create Payment</button>
        </div>
      </div>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/ms/ms/resources/views/admin/receive_payment.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Account</h2>
          </div>
        </div>
      </div>

      <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/account" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?>

      <div class="row">
      
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <label for="sel1">Account Type</label>
              <select class="form-control" id="expense" name="account_type">
                <option value="Account Receivable">Account Receivable</option>
                <option value="Account Payable">Account Payable</option>
                 <option value="Expense">Expense</option>
                 <option value="Cash On Hand">Cash On Hand</option>
                 <option value="Bank Account">Bank Account</option>
                  <option value="Sale Manegment">Sale Management</option>
                  <option value="Purchase Manegment">Purchase Management</option>
              </select>
            </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Account Name</label>
                  <input type="text" name="account_name" class="form-control" id="">
                </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Description</label>
                  <input type="text" name="description" class="form-control" id="">
                </div>
          </div>
        </div>
        <div id="fnivel2">
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Balance</label>
                  <input type="text" name="balance" class="form-control" id="">
                </div>
          </div>
        </div>
          <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
                  <label for="usr">Date</label>
                  <input type="date" name="date" class="form-control" id="">
                </div>
          </div>
        </div>
</div>
      </div>
      
        <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-8">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>
      </form>
    </div>
    <!-- /page content --> 
    
    

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/add_account_view.blade.php ENDPATH**/ ?>
    
    <?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Purchase Report</h2>
          </div>
        </div>
      </div>
      <!-- <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <select class="form-control" id="">
                <option>Year</option>
                <option>Month</option>
                <option>Week</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <select class="form-control" id="">
                <option>2010</option>
                <option>2011</option>
                <option>2012</option>
                <option>2013</option>
                <option>2014</option>
                <option>2015</option>
                <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
          <div class="Tohead">
            <h4>To</h4>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="createadmininputs">
            <div class="form-group">
              <select class="form-control" id="">
                <option>2011</option>
                <option>2012</option>
                <option>2013</option>
                <option>2014</option>
                <option>2015</option>
                <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="Applybtn">
            <button href="#" class="btnapply btn">Apply</button>
          </div>
        </div>
      -->

        <div class="row">
        <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/search/purchase/invoice/by/date" class="login-form" enctype="multipart/form-data">
                   
                   <?php echo e(csrf_field()); ?>

   
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dateinputcircles">
            <div class="form-group">
              <input type="date" name="date_from">
            </div>
          </div>
        </div>
        <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
          <div class="Tohead">
            <h4>To</h4>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dateinputcircles">
            <div class="form-group">
              <input type="date" name="date_to">
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="Applybtn">
            <button href="#" class="btnapply btn">Apply</button>
          </div>
        </div>

</form>




        <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group">
        <label> customer_name</label>
        </div>
      </div>
  <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/search/purchase/by/invoice" class="login-form" enctype="multipart/form-data">
                   
                   <?php echo e(csrf_field()); ?>


      <div class="col-lg-4">
        <div class="form-group">
          <label></label>
          <select class="selectpicker form-control" data-show-subtext="true" name="supplier_name" id=""  data-live-search="true">
                <option  class="form-control" ></option>
                  
                        <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option  class="form-control"  value="<?php echo e($results->pk_id); ?>" ><?php echo e($results->supplier_name); ?></option>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
       
      </select>
        </div>
      </div>
    
      </div>
    <div class="row">
      <div class="col-lg-2">
        <div class="totalamountp">
          <button type="submit" class="amountbtn btn">Filter</button>
        </div>
      </div>
    </div>
  </form>


      </div>
   
      
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Adminprofilebox">
            <div class="row">
             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
               <div class="accountpayablehead">
             <h4>Purchase Report by Customer</h4>
             <!-- <p>January 1-Faburary 10</p> -->
             </div>
             </div>
            
            </div>
            
            <table class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor2">
                  <tr>
                    <th></th>
                    <th>Credit Rs</th>
                    
                    
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $customer = DB::select("select* from supplier  where pk_id = '$results->supplier_name'");
             ?>
                  <tr>
                    <td ><?php echo e($customer[0]->supplier_name); ?></td>
                     <td><?php echo e($results->total_amount); ?></td>
                   
                  </tr>
                 
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
                
              
                </tbody>
              </table>
           <div class="row">
           <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <div class="totalpayabletable">
            <h4>Total</h4>
           </div>
           </div>
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
             <div class="totalpayabletable">
           
             <p><?php echo e(number_format($total_amount[0]->{'SUM(total_amount)'})); ?></p>
           </div>
           </div>
           </div>
          
           
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ms\mspetroleum\resources\views/admin/purchase_by_invoice_list_views.blade.php ENDPATH**/ ?>
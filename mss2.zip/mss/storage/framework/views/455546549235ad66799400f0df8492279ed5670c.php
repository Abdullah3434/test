<?php $__env->startSection('content'); ?>

<form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/expense" class="login-form">
                   
                   <?php echo e(csrf_field()); ?>

             
             <?php if($errors->any()): ?>
             
             <div class="alert alert-danger">
             <strong></strong> <?php echo e($errors->first()); ?>

             </div>
             <?php endif; ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Create Expense</h2>
          </div>
        </div>
      
      

      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="<?php echo e(url('/')); ?>/admin/home/add/account" class="btn pumpplusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div>
    
        </div>
      <div class="row">
        <div class="field_wrapper ">
          <div class="borderrow">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Payee(optional)</label>
                  <input type="text" class="form-control" name="payee[]" id="usr">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="sel1">Account Name</label>
             
                  <select class="form-control" id="" name="account_name[]">
                  <?php if(count($result)>0): ?>
                  <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($results->account_name); ?>"><?php echo e($results->account_name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="sel1">Payment Method</label>
                  <select class="form-control" id="" name="payment_method[]">
                    <option value="cash">Cash</option>
                    <option value="bank">bank</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="sel1">Payment Account</label>
                  <select class="form-control" id="" name="payment_account[]">
                  <option value="">Select Account</option>
                  <option value="cash">Cash on Hand</option>
                  <?php if(count($result1)>0): ?>
                  <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($results->account_name); ?>"><?php echo e($results->account_name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Description</label>
                  <input type="text" class="form-control" id="" name="description[]">
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="createadmininputs">
                <div class="form-group">
                  <label for="usr">Amount</label>
                  <input type="text" class="form-control" id=""name="amount[]" >
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="plusbutton">
                <button class="add_button plusbtn" type="button" title="Add field"><span class="glyphicon glyphicon-plus"></span></button>
              </div>
            </div>
          </div>
        </div>
      </div>
    
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-7">
          <div class="totalamountp">
            <button type="submit" class="amountbtn btn">Save</button>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    </form>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/add_expense_view.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Sale</h2>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
          <div class="machinename">
        
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="dropbtnstyle">
              <div class="dropdown">
                <div class="btn pumpplusbtn dropdown-toggle" type="button" data-toggle="dropdown"><span class="glyphicon glyphicon-plus"></span>
                </div>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/add/sale">Add Normal Entry</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/add/sale/tax">Add Tax Applicable</a></li>
                  
                </ul>
              </div>
              </div>
              </div>
          </div>
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="dropbtnstyle">
              <div class="dropdown">
                <button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
                Select Field <span class="caret"></span>
                </button>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/sale/by/customer">View sale</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/sale/return/by/customer">View sale Return</a></li>
                  
                </ul>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dateinputcircles">
            <div class="form-group">
              <input type="date" name="bday">
            </div>
          </div>
        </div>
        <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
          <div class="Tohead">
            <h4>To</h4>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dateinputcircles">
            <div class="form-group">
              <input type="date" name="bday">
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="Applybtn">
            <button href="#" class="btnapply btn">Apply</button>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Totalpurchasehead">
            <h4>Total Sale :</h4>
            <p>PKR <?php echo e(number_format($total_amount[0]->{'SUM(total_amount)'})); ?></p>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor">
                  <tr>
                  <th>Bills #</th>
                    <th>Customer Name</th>
                    <th>Total Sale</th>
                    <th>D-Invoice #</th>
                    <th>Current Balance</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $invoice = DB::select("select* from sale where customer_name = '$results->pk_id' and sale_type = 'sale'");
                $total_q1 = DB::select("select SUM(quantity) from detail_sale,sale where detail_sale.sale_id = sale.pk_id and sale.customer_name = '$results->pk_id' and sale.sale_type = 'sale'");
                $total_q2 = DB::select("select SUM(quantity) from detail_tax_sale,sale where detail_tax_sale.sale_id = sale.pk_id and sale.customer_name = '$results->pk_id' and sale.sale_type = 'sale'");
             
                $total_sale = $total_q1[0]->{'SUM(quantity)'} + $total_q2[0]->{'SUM(quantity)'};
                ?>
                  <tr>
                  <td><?php echo e($results->pk_id); ?></td>
                    <td><?php echo e($results->customer_name); ?></td>
                    <td>PKR <?php echo e(number_format($total_sale)); ?></td>
                       <td><a href="<?php echo e(url('/')); ?>/admin/home/view/sale/<?php echo e($results->pk_id); ?>"><?php echo e(count($invoice)); ?> Invoice</a></td>
                    <td>PKR <?php echo e(number_format($results->opening_balance)); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
                 </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/sale_by_customer_list_view.blade.php ENDPATH**/ ?>
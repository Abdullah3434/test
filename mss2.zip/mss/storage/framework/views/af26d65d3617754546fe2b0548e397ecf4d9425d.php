<?php $__env->startSection('content'); ?>
    
    <!-- page content -->
    <div class="right_col" role="main">
    
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>Edit Item</h2>
          </div>
        </div>
      </div>
      <?php if($result>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/main/category/<?php echo e($results->SKU); ?>" class="login-form">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
    <div class="row">
    <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
      <div class="createadmininputs">
           <div class="form-group">
                  <label for="usr">Item</label>
                  <input type="text" value="<?php echo e($results->main_category); ?>" name="mainCategory"  class="form-control" id="">
                </div>
          </div>
    </div>
    </div>
    
      <div class="row">
       <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="editpart">
            <button type="submit" class="btnedit btn">Save</button>
          </div>
        </div>
      </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
     </div>
    <!-- /page content --> 
    
  

          <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/byowmbia/mspetroleum/resources/views/admin/edit_main_category.blade.php ENDPATH**/ ?>
    
<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="viewadminhead">
          <h2>View Accounts</h2>
          </div>
        </div>
         <!-- <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="machinename">
         <h4>Hera Petroleum</h4>
         <h4>92 K Defence,Lahore</h4>
         </div>
         </div> -->
          <!-- <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="create-machine.html" class="btn pumpplusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div> -->
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor">
                  <tr>
                  <th>Date</th>
                    
                    <th>Account Name</th>
                    <th>Description</th>
                    <th>Increase</th>
                    <th>Decrease</th>
                    
                    
                  </tr>
                </thead>
                <tbody>
                 
                  <?php if(count($result3)>0): ?>
            <?php $__currentLoopData = $result3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($results->date); ?></td>
                
                
                
                
                <td><?php echo e($results->recive_from); ?>

                
                    </td>
                
                   
                
          
                  <td><?php echo e($results->description); ?></td>
                    
                    <td><?php echo e($results->amount); ?>


                    </td>

                   </tr>
                  <tr>
                  

                    </tr>
                  <tr>
                   
                   
                    </tr>




                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>
                  <tr>
                   
                  <?php if(count($result4)>0): ?>
            <?php $__currentLoopData = $result4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><?php echo e($results->date); ?></td>
                
                <td><?php echo e($results->payee); ?></td>
               
                  
                  <td><?php echo e($results->description); ?></td>
                  <td></td>
                    <td><?php echo e($results->amount); ?></td>
                   
                   
                  
                   
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php endif; ?>
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ms\mspetroleum\resources\views/admin/view-machine-table.blade.php ENDPATH**/ ?>

    
    <?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Admin</h2>
          </div>
        </div>
      </div>
      
    
      
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-2">
          <div class="Adminprofilebox">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="redheading">
                  <h4>Name</h4>
                </div>
              </div>
              <?php if($result>0): ?>
                          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="blackheading">
                  <h4><?php echo e($results->fname); ?><?php echo e($results->lname); ?></h4>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="redheading">
                  <h4>Email</h4>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="blackheading">
                  <h4><?php echo e($results->username); ?></h4>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="redheading">
                  <h4>Permissions</h4>
                </div>
              </div>

              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Machine_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Machine Management</span> </div>
                    <?php endif; ?>
                  </div>
                   </div>

                   <br>
                   <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Admin_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Admin Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>
<br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Expense_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Expense Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>
                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Customer_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Customer Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>

                  <br>
                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Sales_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Sales Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>
                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Supplier_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Supplier Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>

                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Purchase_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Purchase Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>
                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Category_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Category Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>

                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Report==1): ?>
                    <div class="labels"> <span class="label label-primary">Report</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>
                  <br>

                  <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <?php if($results->Item_Management==1): ?>
                    <div class="labels"> <span class="label label-primary">Item Management</span> </div>
                    <?php endif; ?>
                  </div>
                  </div>




            
              </div>
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-6">
                  <div class="viewadminbtn">
                    <a href="edit-admin.html" class="btnedit btn">Edit</a>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                      
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/ms/ms/resources/views/admin/admin_detail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?> 
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="viewadminhead">
            <h2>View Machines</h2>
          </div>
        </div>
         <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="machinename">
          <?php if(count($result1)>0): ?>
                <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <h4><?php echo e($results->pump_name); ?></h4>
         <h4><?php echo e($results->pump_address); ?></h4>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
         </div>
         </div>
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="plusbutton">
            <a href="<?php echo e(url('/')); ?>/admin/home/add/machine/<?php echo e($result1[0]->pk_id); ?>" class="btn pumpplusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></a>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead class="headbgcolor">
                  <tr>
                    <th>Tank Name</th>
                    <th>Current Stock</th>
                    <th>Machine Name</th>
                    <th>Closing Reading</th>
                   
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $tank_id = $results->tank_id;
                $tank_name = DB::select("select* from tank where pk_id = '$tank_id'");
                ?>
                  <tr>
                    <td><?php echo e($tank_name[0]->tank_name); ?></td>
                    <td><?php echo e($tank_name[0]->opening_stock); ?> <?php echo e($tank_name[0]->uom); ?></td>
                    <td><?php echo e($results->machine_name); ?></td>
                    <td><?php echo e($results->closing_reading); ?></td>
                    <td><a href="<?php echo e(url('/')); ?>/admin/home/view/machine/detail/<?php echo e($results->pk_id); ?>" class="bordersets">view</a> &nbsp;&nbsp;<a href="<?php echo e(url('/')); ?>/admin/home/delete/machine/<?php echo e($results->pk_id); ?>">Delete</a></td>
                  </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content --> 
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mspetroleum\resources\views/admin/machine_list_view.blade.php ENDPATH**/ ?>